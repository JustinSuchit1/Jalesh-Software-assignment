## CLI Commands for Competition Platform

1. **Create a new competition**:
   ```
   flask competition create <name> <description> <date>
   ```

2. **List all competitions**:
   ```
   flask competition list
   ```

3. **View competition results**:
   ```
   flask competition results <competition_id>
   ```

4. **Import results from a CSV file**:
   ```
   flask competition import_results <file_path> <competition_id>
   ```

### CSV File Format for Results:
| user_id | score | ranking |
| ------- | ----- | ------- |
| 1       | 95    | 1       |
| 2       | 85    | 2       |
